
// types/kickbox.d.ts
declare module 'kickbox'; 